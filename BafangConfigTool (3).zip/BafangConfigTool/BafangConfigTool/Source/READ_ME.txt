1) Windows 7 GUI style resource build - in CMD run the following (Delphi 7 must be installed): brcc32 Win7GUI.rc
2) Build the SPComm as a package and install it in Delphi compiler in order to use the way it was used for making this application
